/**
 * A class containing the main method and runs the GameManager to start the Maze game
 */
public class GameRunner {
	public static void main(String[] args) {
		GameManager gm = new GameManager();
	}
}
